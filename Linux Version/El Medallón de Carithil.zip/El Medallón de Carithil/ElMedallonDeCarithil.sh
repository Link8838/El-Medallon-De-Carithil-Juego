#!/bin/bash
echo "[Cargando...]"
java -cp ElMedallonDeCarithil.jar MedallonCarithil
