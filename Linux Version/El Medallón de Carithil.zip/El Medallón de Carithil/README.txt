Hola, éste juego se ejecuta usando Java, si no lo tienes, bueno, pues, te recomiendo
descargarlo...

Teniendo Java, abre en TERMINAL la carpeta donde está el archivo, ElMedallonDeCarithil.jar

Ejecuta el juego con éste comando: 

     ./ElMedallonDeCarithil.sh

*EN CASO DE PERMISO DENEGADO USAR:
    
     chmod +x ElMedallonDeCarithil.sh

Luego mandas ejecutar de nuevo.

Recomiedo altamente ejecutar el juego en PANTALLA COMPLETA, ya que algunos Ascii Art
son demasiado grandes, o los cuadros de texto no se verían. Si la fuente de tu terminal 
es muy grande, si puedes poner una mas pequeña sería mejor, o si lo prefieres presiona "Ctrl -" para minimizar un poco y que se puedan leer todos los textos, si no solo sube un poco para
leer lo que no quepa en pantalla. Cada que haya un Ascii Art hay un texto que leer.

El archivo "Registro.rmdc" es aquel que juagará tu partida, recomiendo no tocarlo para no 
perder tus avances.

Te dejo un .png con el logo del juego por si quieres decorar la carpeta del juego, click derecho
sobre la carpeta -> Propiedades, y presiona el icono de la carpeta.


Gracias por descargar el juego.

                                                                            -Link8838
